<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Cabin Photos,  Blue Ridge Mountains Photos, Georgia, Mt. Pisgah Photos,Cabin Rental, North Georgia, Blue Ridge</TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="keywords" CONTENT="Cabin Photos, Mt. Pisgah Photos, Blue Ridge MountainsPhotos, Georgia, Blue Ridge Cabin Rentals,luxury lodge,luxury cabins, Blue Ridge GA,Blue Ridge Georgia, North Georgia Mountains,fighting town creek,aska adventure area, blue ridge mountains ga,,Toccoa River, Appalachian mountains,mountain paradise,">
<META NAME="description" CONTENT="Solitude cabin photos">


<script language="JavaScript">
<!--

var popUpWin=0;
function popUpWindow(URLStr) //, left, top, width, height)
{
  if(popUpWin)
  {
    if(!popUpWin.closed) popUpWin.close();
  }
  
   
  popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+ (screen.width-50) + ',height=600,left=25, top=50,screenX=100,screenY=50');
  popUpWin.focus();
}
/*
function popuprefresh() 
{
	//javascript:setTimeout(opener.window.location.reload(true),5000);
	//javascript:onunload(opener.window.location.reload(true));
	//javascript:opener.window.location.reload(true);
	//javascript:self.close();	
	
}

function toclosepopupandreloadopener(theform,pgid,hostpath,mode)
{

//alert("http://"+hostpath+"/member/managesection/view.php?id="+pgid+"&mode="+mode);
var GOTOURL="http://"+hostpath+"/member/managesection/view.php?id="+pgid+"&mode="+mode;

	//if(theform.window.close)
	//{
		alert(GOTOURL);
		alert(window.opener);
		//if(pgid !="" && hostpath != "" && mode !="")
		//{
			window.opener.location.href=GOTOURL;
			//window.opener.focus(); 
			window.close();        	
		//}
	//}	
}*/
//-->
</script> 


 

<style>
body.screenimage{
	
		
background-image:url(http://www.siteproplus.com/accounts/solitude/);
background-repeat:repeat;
background-color: #000000;
}
.heading
{
    COLOR: #FFFFFF;
    FONT-FAMILY: verdana,arial;
    FONT-SIZE: 20px;
}
.header
{
    background: #;
    
    color: #00ff00;
   height: px;
    
}
.top_nev
{
    background: #ffffff;
	height: 30px;
	text-align:center	;
}
.link 
{
	FONT-FAMILY: Arial;
	color: #000000;
    	FONT-SIZE: 9pt;
	font-weight: bold;
	font-style: normal;
	text-decoration: normal;

}
a.link:link 
{
	FONT-FAMILY: Arial;
	color: #000000;
    	FONT-SIZE: 9pt;
	font-weight: bold;
	text-decoration:none;

}
a.link:visited 
{
	FONT-FAMILY: Arial;
	color: #000000;
    	FONT-SIZE: 9pt;
	font-weight: bold;
	text-decoration:none;
}
a.link:hover 
{
text-decoration:none;
color: #ffffff;
}

td.link 
{
padding:2px 10px 2px 10px; 
cursor:hand;
}
a.copyright1
{
    background: #CCA878;
    FONT-FAMILY: verdana, arial;
	color: #000000;
    FONT-SIZE: 10px;
	height: px;
	text-align: ;
	LINE-HEIGHT: 150%;
	text-decoration: #none;
}

td.link11 
{
color:#000000;
}
.content
{
    FONT-FAMILY: verdana, arial;
	color: #;
    FONT-SIZE: 10pt;
	LINE-HEIGHT: 110%;
	
}
.copyright
{
    background: #CCA878;
    FONT-FAMILY: verdana, arial;
	color: #000000;
    FONT-SIZE: 10px;
	height: px;
	text-align: ;
	LINE-HEIGHT: 150%;
}
.copyrightemail
{
    background: #CCA878;
    FONT-FAMILY: verdana, arial;
	color: #000000;
    FONT-SIZE: 10px;
	height: px;
	text-align: ;
	LINE-HEIGHT: 150%;
}

div.sss{
text-align:Center;
}
table.marig{
margin-top:5px;
margin-right:5px;
margin-bottom:5px;
margin-left:5px;
}

.main-table
{
	background: #ffffff;
	border: solid #CCA878 10px;
	
}
.td.main-table
{
	width: 770px;
	text-align: Center;
margin: 0px 0px 0px 0px;
		background: #FFFFFF;
}
.bodytext-table
{
	background: #ffffff;
	border:solid #CCA878 0px;
}
.td.bodytext-table
{
	width: 100 %;
	text-align: center;
	margin:1px 1px 1px 1px;
	background: #ffffff;
}
.td.bodytext-table1
{
	
	
	background: #ffffff;
}
.white-link
{
	color: #ffffff;
	font-weight: bold
	FONT-FAMILY: verdana,arial;
}

.addlink
{
    COLOR: #000000;
	FONT-FAMILY: arial, verdana;
	FONT-SIZE: 12px;
	 TEXT-DECORATION: none;
	 	font-weight: bold

}
.addlink:hover
{
    COLOR: #0000FF;
    TEXT-DECORATION: Underline;
}

.ours
{
    COLOR: #000000;
	FONT-FAMILY: arial, verdana;
	FONT-SIZE: 12px;
	 TEXT-DECORATION: none;
	 	font-weight: none;

}
.buttonbgimagestyle
{
     background-image: url(http://www.siteproplus.com/accounts/solitude/images/thumb/);
	
     height:31;
     width:;
     background-repeat: repeat;
 
}
.buttonbgimagestyle1
{
     background-image: url(http://www.siteproplus.com/accounts/solitude/images/thumb/);
     height:31;
     width:;
     background-repeat: repeat;
 
}
.top
{
    COLOR: #000000;
	FONT-FAMILY: arial, verdana;
	FONT-SIZE: 11px;
	 TEXT-DECORATION: none

}
.top:hover
{
    COLOR: #0000FF;
    TEXT-DECORATION: Underline;
}

.toplinklegend
{
	color: #000000;
	font-size: 10px;
	font-weight: bold;
FONT-FAMILY: verdana, arial;
text-decoration: none
}

.toplinklegend:hover
{
	color: #ff0000;

	text-decoration: underline
}
.leftlinklegend
{
	color: #3D3D3D;
	font-size: 9px;
	font-weight: normal;
FONT-FAMILY: verdana, arial;
text-decoration: none;
}

.leftlinklegend:hover
{
	color: #ff0000;

	text-decoration: underline
}

.headinglegend
{
	color: #000000;
	font-size: 11px;
	font-weight: bold;
FONT-FAMILY: verdana, arial;
 }
 

.footerlegend
{
	color: #7F7F7F;
	font-size: 10px;
	font-weight: normal;
FONT-FAMILY: verdana, arial;
}

.popupsitename
{
	color: #000000;
	font-size: 27px;
	font-weight: bold;
FONT-FAMILY: verdana, arial;
text-decoration: none
}


// style use in the popup windows for edit

.popuptext
{
	color: #000000;
	font-size: 11px;
	font-weight: normal;
FONT-FAMILY: verdana, arial;
text-decoration: none
}
.popupaddcontent
{
	color: #000000;
	font-size: 17px;
	font-weight: bold;
FONT-FAMILY: verdana, arial;
text-decoration: none
}


// style used in contactsdisplay, articlesdisplay etc. by Vinay dtd Aug-16
.contact-page-head {
	font-family: tahoma;
	font-size: 14px;
	font-weight: bold;
	color: 326495;
	text-decoration: none;
}
.semihead {

	font-family: tahoma;
	font-size: 12px;
	font-weight: bold;
	color: 326495;
	text-decoration: none;
}
.content-do {


	font-family: tahoma;
	font-size: 11px;
	font-weight: normal;
	color: 326495;
	text-decoration: none;
}
.semiheadarticle {


	font-family: tahoma;
	font-size: 12px;
	font-weight: bold;
	color: 326495;
	text-decoration: underline;
}
.more-do {



	font-family: tahoma;
	font-size: 11px;
	font-weight: normal;
	color: #0066CC;
	text-decoration: underline;
}


<!---  style used in site background image and image by Sukhi,Vinay dtd Aug-25  -->

<!---  style used in custom forms by Sukhi,Chetan dtd Sep 06  -->
.VisionToInput
{
    BACKGROUND-COLOR: #FFFFFF;
    BORDER-BOTTOM: #7280AA 1px solid;
    BORDER-LEFT: #7280AA 1px solid;
    BORDER-RIGHT: #7280AA 1px solid;
    BORDER-TOP: #7280AA 1px solid;
    COLOR: #000000;
    MARGIN: 0px;
    PADDING-BOTTOM: 2px;
    PADDING-LEFT: 2px;
    PADDING-RIGHT: 2px;
    PADDING-TOP: 2px
}

INPUT.submitstyle
{
    BACKGROUND-COLOR: #EDEEF1;
    BORDER-BOTTOM: #7280AA 1px solid;
    BORDER-LEFT: #7280AA 1px solid;
    BORDER-RIGHT: #7280AA 1px solid;
    BORDER-TOP: #7280AA 1px solid;
    COLOR: black;
    MARGIN: 0px;
    PADDING-BOTTOM: 2px;
    PADDING-LEFT: 2px;
    PADDING-RIGHT: 2px;
    PADDING-TOP: 2px
}


</style>
<div align="Center">
<!-- ********************************************************************************* -->



<BODY class="screenimage" topmargin=0 leftmargin=0 marginheight=0 marginwidth=0>
<!--MAIN TABLE STARTS HERE--> 


<table class="main-table"  border="0" width="780" cellpadding="0" cellspacing="0">
<tr>
<td>

<!--TOP TABLE STARTS HERE-->
<!-- this was for backgroung image spreading throughtout the header section 
<table border=0 width=780 cellpadding=0 cellspacing=0 class="header">
 -->
 <table border=0 width=780 cellpadding=0 cellspacing=0 class="header">
<tr>
		<td>
				<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="780" height="235">
          <param name="movie" value="http://www.siteproplus.com/accounts/solitude/images/thumb/blueridgeluxurycabin.swf">
          <param name="quality" value="high">
          <param name="wmode" value="transparent">
          <embed src="http://www.siteproplus.com/accounts/solitude/images/thumb/blueridgeluxurycabin.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="780" height="235">
		  </embed>
        	</object>
				</td>
</tr>
</table>
<!--TOP TABLE ENDS HERE-->

<!--MIDDLE TABLE STARTS HERE-->
<table border=0 width=780 cellpadding=0 cellspacing=0>
	<tr> 
		<td width=150  valign=top class="top_nev">
			<!--LINK TABLE STARTS HERE-->
			<center>
			<table width=139 cellpadding=1 cellspacing=4>
				<tr><td height='15'>&nbsp;</td></tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/index.html" class="link">Home Page</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/page2.html" class="link">Cabin Description</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/258789.html" class="link">Amenities</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/203281.html" class="link">Rates / Policies</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/149225.html" class="link">Availability Calendar</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/163053.html" class="link">Specials!</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/photoGallery.php" class="link">Photo Gallery</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/287147.html" class="link">Area Lakes Rivers & Streams</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/faqs.html" class="link">Questions & Answers</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/articles.html" class="link">Top 10 Things To Do</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/282933.html" class="link">Water Activities</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/297341.html" class="link">Restaurants</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/166917.html" class="link">Activities</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/223303.html" class="link">Attractions</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/198171.html" class="link">Resources</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/form_169539.html" class="link">Request A Quote</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/form_161.html" class="link">Contact Us</a>
						</td>
						</tr>
											</table></td>
				</tr>
				
				<tr>
					<td>
																						<table height='25' width="130" cellspacing="2" cellpadding="0" border=0 bgcolor="#000000">
						<tr>
						<td class='link' onmouseover="bgColor='777777'" onmouseout="bgColor='CCA878'" bgColor=#CCA878 align=Center>
																
						<a href="/quotes.html" class="link">Guest Book</a>
						</td>
						</tr>
											</table></td>
				</tr>
							<tr><td height='15'>&nbsp;</td></tr>	
			</table>
			</center>
			<!--LINK TABLE ENDS HERE-->
		</td>
				<td width=630  valign=top class="bodytext-table1">
		<table border=0 width=100% cellpadding=5 cellspacing=5>
				<tr><td valign=top>
			<!--TEXT TABLE STARTS HERE-->
			
			
										<?
$username = 'solitude';
$AccessFrom = 'SITE';
include($_SERVER["DOCUMENT_ROOT"]."/applications/photoSpp/photoGallery.php");
?>
 
									
			<!--TEXT TABLE ENDS HERE-->
			</td></tr>
			
			</table><br><br>
		</td>
	</tr>

	
</table>
<!--MIDDLE TABLE ENDS HERE-->

<!--BOTTOM TABLE STARTS HERE-->
<table border=0 width=780 cellpadding=0 cellspacing=0>
	
		<tr>
		<td class="copyright" align="center"><img src="images/spacer.gif" alt="" border=0 width=1 height=5>
				
			<a href="/index.html" class='copyrightemail'>Home Page</a> | 
					<a href="/page2.html" class='copyrightemail'>Cabin Description</a> | 
					<a href="/258789.html" class='copyrightemail'>Amenities</a> | 
					<a href="/203281.html" class='copyrightemail'>Rates / Policies</a> | 
					<a href="/photoGallery.php" class='copyrightemail'>Photo Gallery</a> | 
					<a href="/166917.html" class='copyrightemail'>Activities</a> | 
					<a href="/form_161.html" class='copyrightemail'>Contact Us</a>
					</td>
	</tr>
		<tr>
		<td background="images/bottom-bg.gif" align=center class="copyright"><a href='mailto:barbara@blueridgeluxurycabin.com' class='copyrightemail'>barbara@blueridgeluxurycabin.com</a><br>&copy; 2006 Blue Ridge Luxury Cabin Rental<br>P.O. Box 1084 Woodstock, GA 30188<br>678-462-7911 or 770-928-1687
		
		</td>
	</tr>
		<tr>
		<td class="copyright"><img src="images/spacer.gif" alt="" border=0 width=1 height=5></td>
	</tr>
</table>

<!--BOTTOM TABLE ENDS HERE-->
</td>
</tr>
</table>

</BODY>
</div>
</HTML>