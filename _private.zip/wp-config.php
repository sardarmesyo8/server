<?php
include('/home/solitude/wp-config.php');