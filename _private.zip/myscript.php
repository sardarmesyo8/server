<?php

	 function cleanUp($field)
	{
         //Remove line feeds
         $ret = str_replace("\r", "", $field);
         $ret = str_replace("\n", "", $ret);
         // Remove injected headers
         $find = array("/bcc\:/i",
                 "/Content\-Type\:/i",
                 "/Mime\-Type\:/i",
                 "/cc\:/i",
                 "/to\:/i");
         $ret = preg_replace($find, "", $ret);
         $ret = str_replace(";", "", $ret);
         $ret = str_replace(":", "", $ret);
         $ret = str_replace(",", "", $ret);
         return $ret;
	}

	function is_valid_email($sender_mail) {
		if(preg_match('/^[a-z0-9\.\-\_]+@[a-z0-9\.\-\_]+\.[a-z]{2,4}$/i',$sender_mail) > 0) 
			return true;
		return false;
	}
    $variables  = $_POST;
    $FORM_SENDER_NAME = cleanUp($_POST['FORM_SENDER_NAME']);
	$FORM_SENDER_EMAIL = cleanUp($_POST['FORM_SENDER_EMAIL']);
	$FORM_SENDER_SUBJECT = cleanUp($_POST['FORM_SENDER_SUBJECT']);
	$FORM_SENDER_SITE = cleanUp($_POST['FORM_SENDER_SITE']);
	$message = "Dear $FORM_SENDER_NAME : \n\n";
	$message .= "You have received following data from the website: \n\n";
	$message .= "SITENAME : $FORM_SENDER_SITE \n\n";
	$message .= "---------------------------------------------------\n\n";
	$userip = ($_SERVER['X_FORWARDED_FOR']) ? $_SERVER['X_FORWARDED_FOR'] :$_SERVER['REMOTE_ADDR'];

	$headers = "From: <no-reply@siteproplus.com>\r\n";
	$headers .= "Reply-to: no-reply@siteproplus.com\r\n";
	$headers .= "Return-Path: no-reply@siteproplus.com\r\n";
	$headers .= "X-Mailer: PHP/".phpversion()."\r\n";
	$headers .= "X-From-IP: ".$userip."\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	
	/* -------------------------------------------------------- 
	$siteProFormValidationFile = $_POST['FORM_SENDER_NAME'].'_formValidation.php';
	if(@is_file($siteProFormValidationFile)){
	   @include_once($siteProFormValidationFile);
	}
	/* -------------------------------------------------------- */
	foreach ($variables as $key => $values)
	{
		if($key=="redirectpage" || $key == "FORM_SENDER_EMAIL" || $key == "FORM_SENDER_SUBJECT" || $key == "FORM_SENDER_NAME" || $key == "submit" || $key == "FORM_SENDER_SITE")
		{
			
			continue;	
			
		}
		else 
		{
			
			if(is_array($values))
			{
				foreach ($values as $k => $val)	
				{
					$message .= "$key           =             $val \n\n";
				}
			}
			else 
			{
				$message .= "$key           =             $values \n\n";
			}	
		}	
	}
	
	$message .= "---------------------------------------------------\n\n";
	$message .= "Form Forwarder: www.siteproplus.com\n\n";


// if($send) {
  if(is_valid_email($FORM_SENDER_EMAIL))
	{
		
	mail($FORM_SENDER_EMAIL,$FORM_SENDER_SUBJECT,$message,$headers);
	header("Location:".$variables['FORM_SENDER_SITE']."/".$variables['redirectpage']);

	}
	?>
